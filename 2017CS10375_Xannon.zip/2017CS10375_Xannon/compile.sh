g++ -O3 game.cpp -o bot
g++ -O3 game2.cpp -o bot2
g++ -O3 game3.cpp -o bot3
