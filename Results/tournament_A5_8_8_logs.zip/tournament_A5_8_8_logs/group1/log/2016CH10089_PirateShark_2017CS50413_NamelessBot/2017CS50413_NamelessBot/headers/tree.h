#ifndef TREE_H
#define TREE_H

#include "node.h"

void create_tree(Node* root,int d);

#endif
