#!/bin/bash
g++ A2S.cpp -o CustomPlayer -O3