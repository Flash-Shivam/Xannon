#!/bin/bash
./CustomPlayer