#include <iostream>
#include <vector>
#include <string>
#include <tuple>
#include <climits>

using namespace std;

int player_id, gameTime;
int n = 10; int m = 10; 
int row= 10 ; int col= 10;
int** board;
int MAX_DEPTH=1;

int  utility (int** arr , int d)
{
  d++;
  int ret = 0; int cnt = 0; int cnt1 = 0; int x[] = {-1 , 0 , 1}; int y[] = {-1 , 0 , 1};
  int a = 0; int b = 0;
    for (int i = 0; i< n ; i++){
      for (int j = 0; j < m ; j++){
        if(arr[i][j]==2)ret+= (i*i+1)/2, cnt++;
        if(arr[i][j]==-2)ret-= ((n-1-i)*(n-1-i)+1)/2 , cnt1++;
        if(arr[i][j]==1) a++;
        if(arr[i][j]==-1) b++;
        ret += (cnt)/2;
        ret-= (cnt1)/2;
        if (arr[i][j]==2 ){
          for (int k = 0; k < 3; k++){
            for (int l = 1; l<3; l++){
                if (j+x[k]>=0 && j+x[k]<m  && i+y[l]>=0 && i+y[l]<n && arr[i+y[l]][j+x[k]] == 2){
                  if (j+2*x[k]>=0 && j+2*x[k]<m  && i+2*y[l]>=0 && i+2*y[l]<n && arr[i+2*y[l]][j+2*x[k]] ==2){
                    if(j<4 && x[k]<0) ret -= i;
                    else if (j>=4 && x[k]>0 ) ret-=i;
                    else {
                       if (k!=1) ret+=(i+2);
                       else if (k==1) ret+= (i+2)/2;
                       if(l==1) if (i < 3) ret -=(i-1);
                    }
                 }
                }
              }
            }
          }
        if (arr[i][j]== - 2 ){
          for (int k = 0; k < 3; k++){
            for (int l = 0; l<2; l++){
                if (j+x[k]>=0 && j+x[k]<m  && i+y[l]>=0 && i+y[l]<n && arr[i+y[l]][j+x[k]] == -2){
                  if (j+2*x[k]>=0 && j+2*x[k]<m  && i+2*y[l]>=0 && i+2*y[l]<n && arr[i+2*y[l]][j+2*x[k]] == - 2){
                    if(j<4 && x[k]<0) ret -= i;
                    else if (j>=4 && x[k]>0 ) ret-=i;
                    else {
                       if (k!=1) ret+=(i+2);
                       else if (k==1) ret+= (i+2)/2;
                       if(l==1) if (i < 3) ret-=(i-1);
                    }
                 }
                }
              }
            }
          }
        }
     }

  if (player_id==2){
      if(a == 3) ret -= 500;
      if(a <= 2) ret -= 1000;
      if (b==3) ret += 500;
      if (b<=2) ret+= 20000;
    return ret;
  }
  else{
    ret=(-1*ret);
      if(a == 3) ret += 500;
      if(a == 2) ret += 20000;
      if (b== 3) ret -= 500;
      if (b == 2) ret  -= 1000;
    return ret;
  }
  // if (player_id==2){
  //     if(a == 3) ret -= 10000/(d+d%2);
  //     if(a <= 2) ret -= 10000/(d+d%2);
  //     if (b==3) ret += 10000/(d+d%2);
  //     if (b<=2) ret+= 10000/(d+d%2);
  //   return ret;
  // }
  // else{
  //   ret=(-1*ret);
  //     if(a == 3) ret += 10000/(d+d%2);
  //     if(a == 2) ret += 10000/(d+d%2);
  //     if (b== 3) ret -= 10000/(d+d%2);
  //     if (b == 2) ret  -= 10000/(d+d%2);
  //   return ret;
  //}
}

typedef struct node
{
  int x1, y1, x2, y2;
  char m;
  // int alpha, beta;
  int** arr;
  int hValue;  
  vector<node*> v;
} node;

node* createNode(int** arr)
{
  node* n1= new node;

  n1->arr= new int*[n];
  for (int i=0; i<n; i++)
  {
    n1->arr[i]= new int[m];
  }

  // n1->hValue= utility(arr);

  for (int i = 0; i<n; i++)
  {
    for(int j = 0; j<m; j++)
      n1->arr[i][j] = arr[i][j];
  }
  return n1;
}

node* createNode(int** arr, int x1, int y1, char M, int x2, int y2)
{
  node* n1= new node;

  n1->arr= new int*[n];
  for (int i=0; i<n; i++)
  {
    n1->arr[i]= new int[m];
  }

  n1->x1= x1;
  n1->y1= y1;
  n1->x2= x2;
  n1->y2= y2;
  n1->m= M;

  // n1->hValue= utility(arr);

  for (int i = 0; i<n; i++)
  {
    for(int j = 0; j<m; j++)
      n1->arr[i][j] = arr[i][j];
  }
  return n1;
}

void displayNode(node *n1)
{
  for (int i=0; i<n; i++)
  {
    for (int j=0; j<m; j++)
      cout << n1->arr[i][j] << "\t";
    cout << endl << endl;
  }
}

void parseData(string data)
{
  int i=0;
  string tok = "";

  while (data[i]!=' ')
  {
    tok += data[i];
    i++;
  }


  player_id = stoi(tok);

  i++;

  tok = "";
  while (data[i]!=' ')
  {
    tok += data[i];
    i++;
  }

  n = stoi(tok);

  i++;

  tok = "";
  while (data[i]!=' ')
  {
    tok += data[i];
    i++;
  }

  m = stoi(tok);

  i++;

  tok = "";
  while (i<data.length())
  {
    tok += data[i];
    i++;
  }

  gameTime = stoi(tok);

}

void initializeBoard()
{
   board= new int*[n];
  for (int i=0; i<n; i++)
  {
    board[i]= new int[m];
  }
  for (int i=0; i<n; i++)
  {
    for (int j=0; j<m; j++)
      board[i][j]=0;
  }

  for (int i = 0; i< m;i+=2)
  {
    board[0][i]= 1;
    board[n-1][i+1]= -1;
  }

  for (int i = 0; i < 3; i++)
  {
    for (int j = 0 ; j < 10; j+=2)
    {
      board[i][j+1]=2;
      board[n-i-1][j]=-2;
    }
  }
}

void displayBoard()
{
  for (int i=0; i<n; i++)
  {
    for (int j=0; j<m; j++)
      cout << board[i][j] << "\t";
    cout << endl << endl;
  }
}

void getValidWhiteMoves(node* root)
{
  int x[3] = {-1 , 0 ,1};
  int y[3] = {-1 , 0 ,1};

  // moving a soldier, normal movement and sideways capture
  for (int i = 0; i < n; i++)
  {
    for(int j = 0;j < m; j++)
    {
      if (root->arr[i][j]==2)
      {
        for (int k = 0; k < 3; k++)
        {
          if (j+x[k]>=0 && j+x[k]<m  && i+1<n && root-> arr[i+1][j+x[k]]<=0)
         {
              int a = root->arr[i+1][j+x[k]];
              root->arr[i+1][j+x[k]]= 2;
              root->arr[i][j]=0;
              root->v.push_back(createNode(root->arr , i , j , 'M' , i+1 , j+x[k]));
              root->arr[i+1][j+x[k]]= a;root->arr[i][j]=2;
          }
          if (k!=1 && j+x[k]>=0 && j+x[k]<m && root-> arr[i][j+x[k]]<0)
          {
              int a = root->arr[i][j+x[k]];
              root->arr[i][j+x[k]]= 2;
              root->arr[i][j]=0;
              root->v.push_back(createNode(root->arr , i , j , 'M' , i, j+x[k]));
              root->arr[i][j+x[k]]= a;root->arr[i][j]=2;
          }
        }
      }
    }
  }

  // if enemy is adjacent, retreat
  for (int i = 0; i < n; i++)
  {
    for(int j = 0;j < m; j++)
    {
      if (root->arr[i][j]==2 )
      {
        for (int k = 0; k < 3; k++)
        {
          for (int l =1; l < 3; l++)
          {
            if (j+x[k]>=0 && j+x[k]<m  && i+y[l]<n && i+y[l]>=0 && root->arr[i+y[l]][j+x[k]] == -2)
            {
              int a;
              if (i-2 >= 0 && root->arr[i-2][j]<=0)
              {
                a = root->arr[i-2][j];
                root->arr[i-2][j] = 2;
                root->arr[i][j]=0;
                root->v.push_back(createNode(root->arr , i , j , 'M' , i-2 , j));
                root->arr[i-2][j]= a;root->arr[i][j]=2;
              }
              if (i-2 >= 0 && j+2< m && root->arr[i-2][j+2]<=0 ){
                a = root->arr[i-2][j+2];
                root->arr[i-2][j+2] = 2;
                root->arr[i][j]=0;
                root->v.push_back(createNode(root->arr , i , j , 'M' , i-2 , j+2));
                root->arr[i-2][j+2]= a;root->arr[i][j]=2;
              }
              if (i-2 >= 0 && j-2>=0 &&  root->arr[i-2][j-2]<=0 )
              {
                a = root->arr[i-2][j-2];
                root->arr[i-2][j-2] = 2;
                root->arr[i][j]=0;
                root->v.push_back(createNode(root->arr , i , j , 'M' , i-2 , j-2));
                root->arr[i-2][j-2]= a;root->arr[i][j]=2;
              }
            }
          }
        }
      }
    }
  }

  // cannon movements and bombing
  for (int i = 0; i < n;i++)
  {
    for (int j = 0; j < m; j++)
    {
      if (root->arr[i][j]==2 )
      {
        for (int k = 0; k < 3; k++)
        {
          for (int l =1; l < 3; l++)
          {
            if (k==0 && l==1 || k==1&&l==1)
              continue;
            if (j+x[k]>=0 && j+x[k]<m && i+y[l]>=0 && i+y[l]<n && root->arr[i+y[l]][j+x[k]] == 2)
            {
              if (j+2*x[k]>=0 && j+2*x[k]<m && i+2*y[l]>=0 && i+2*y[l]<n && root->arr[i+2*y[l]][j+2*x[k]] ==2)
              {
                int m1 = 3;
                if (j+3*x[k]>=0 && j+3*x[k]<m && i+3*y[l]>=0 && i+3*y[l]<n && root->arr[i+3*y[l]][j+3*x[k]] ==0)
                {
                  int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                  root->arr[i+m1*y[l]][j+m1*x[k]] = 2;
                  root-> arr[i][j] = 0;
                  root->v.push_back(createNode(root->arr , i , j , 'M' ,i+3*y[l] , j+3*x[k] ));
                  root->arr[i+m1*y[l]][j+m1*x[k]]=a; root->arr[i][j]=2;
                  m1 = 4;
                  if (j+m1*x[k]>=0 && j+m1*x[k]< m && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]<=0)
                  {
                    int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                    root->arr[i+m1*y[l]][j+m1*x[k]] = 0;
                    root->v.push_back(createNode(root->arr , i+2*y[l] , j+2*x[k] , 'B' ,   i+4*y[l] , j+4*x[k]));
                    root->arr[i+m1*y[l]][j+m1*x[k]]=a;
                  }
                  else if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]==0)
                  {
                    m1= 5;
                    if (j+m1*x[k]>=0 && j+m1*x[k]<m && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]<=0)
                    {
                      int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                      root->arr[i+m1*y[l]][j+m1*x[k]] = 0;
                      root->v.push_back(createNode(root->arr, i+2*y[l] , j+2*x[k] , 'B' ,   i+5*y[l] , j+5*x[k]));
                      root->arr[i+m1*y[l]][j+m1*x[k]]=a;
                    }
                  }
                }
                m1= -1;
                if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]] ==0)
                {
                  int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                  root->arr[i+m1*y[l]][j+m1*x[k]] = 2;
                  root-> arr[i+2*y[l]][j+2*x[k] ] = 0;
                  root->v.push_back(createNode(root->arr , i+2*y[l] , j+2*x[k] , 'M' ,i-y[l] , j-x[k] ));
                  root->arr[i+m1*y[l]][j+m1*x[k]]=a; root->arr[i+2*y[l]][j+2*x[k] ]= 2;
                  m1 = -2;
                  if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]<=0)
                  {
                    int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                    root->arr[i+m1*y[l]][j+m1*x[k]] = 0;
                    root->v.push_back(createNode(root->arr , i , j , 'B' ,   i-2*y[l] , j-2*x[k]));
                    root->arr[i+m1*y[l]][j+m1*x[k]]=a;
                  }
                  else if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]==0)
                  {
                    m1= -3;
                    if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]<=0)
                    {
                      int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                      root->arr[i+m1*y[l]][j+m1*x[k]] = 0;
                      root->v.push_back(createNode(root->arr, i , j, 'B' ,   i-3*y[l] , j-3*x[k]));
                      root->arr[i+m1*y[l]][j+m1*x[k]]=a;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

void getValidBlackMoves(node* root)
{
  int x[3] = {-1 , 0 ,1};
  int y[3] = {-1 , 0 ,1};

  // moving a soldier, normal movement and sideways capture
  for (int i = 0; i < n; i++)
  {
    for(int j = 0;j < m; j++)
    {
      
      if (root->arr[i][j]==-2)
      {
        for (int k = 0; k < 3; k++)
        {
          if (j+x[k]>=0 && j+x[k]<m  && i-1>=0 && root-> arr[i-1][j+x[k]]>=0)
          {
            int a = root->arr[i-1][j+x[k]];
            root->arr[i-1][j+x[k]]= -2;
            root->arr[i][j]=0;
            root->v.push_back(createNode(root->arr , i , j , 'M' , i-1, j+x[k]));
            root->arr[i-1][j+x[k]]= a;root->arr[i][j]=-2;
          }
          if (k!=1 && j+x[k]>=0 && j+x[k]<m && root-> arr[i][j+x[k]]>0)
          {
            int a = root->arr[i][j+x[k]];
            root->arr[i][j+x[k]]= -2;
            root->arr[i][j]=0;
            root->v.push_back(createNode(root->arr , i , j , 'M' , i, j+x[k]));
            root->arr[i][j+x[k]]= a;root->arr[i][j]=-2;
          }
        }
      }
    }
  }

  // if enemy is adjacent, retreat
  for (int i = 0; i < n; i++)
  {
    for(int j = 0;j < m; j++)
    {
      if (root->arr[i][j]==-2 )
      {
        for (int k = 0; k < 3; k++)
        {
          for (int l =0; l < 2; l++)
          {
            if (j+x[k]>=0 && j+x[k]<m  && i+y[l]<n && i+y[l]>=0 && root->arr[i+y[l]][j+x[k]] == 2)
            {
              int a;
              if (i+2 < n &&  root->arr[i+2][j]>=0  )
              {
                a = root->arr[i+2][j];
                root->arr[i+2][j] = -2;
                root->arr[i][j]=0;
                root->v.push_back(createNode(root->arr , i , j , 'M' , i+2, j));
                root->arr[i+2][j]= a;root->arr[i][j]=-2;
              }
              if (i+2 <n && j+2< m && root->arr[i+2][j+2]>=0)
              {
                a = root->arr[i+2][j+2];
                root->arr[i+2][j+2] = -2;
                root->arr[i][j]=0;
                root->v.push_back(createNode(root->arr , i , j , 'M' , i+2 , j+2));
                root->arr[i+2][j+2]= a;root->arr[i][j]=-2;
              }
              if (i+2 < n && j-2>=0 && root->arr[i+2][j-2]>=0)
              {
                a = root->arr[i+2][j-2];
                root->arr[i+2][j-2] = -2;
                root->arr[i][j]=0;
                root->v.push_back(createNode(root->arr , i , j , 'M' , i+2 , j-2));
                root->arr[i+2][j-2]= a;root->arr[i][j]=-2;
              }
            }
          }
        }
      }
    }
  }

  // cannon movements and bombing
  for (int i = 0; i < n;i++)
  {
    for (int j = 0; j < m; j++)
    {
      if (root->arr[i][j]==-2 )
      {
        for (int k = 0; k < 3; k++)
        {
          for (int l =0; l < 2; l++)
          {
            if (k==0 && l==1 || k==1&&l==1)
              continue;
            if (j+x[k]>=0 && j+x[k]<m  && i+y[l]>=0 && i+y[l]<n && root->arr[i+y[l]][j+x[k]] == -2)
            {
              if (j+2*x[k]>=0 && j+2*x[k]<m && i+2*y[l]>=0 && i+2*y[l]<n && root->arr[i+2*y[l]][j+2*x[k]] ==-2)
              {
                int m1 = 3;
                if (j+3*x[k]>=0 && j+3*x[k]<m  && i+3*y[l]>=0 && i+3*y[l]<n && root->arr[i+3*y[l]][j+3*x[k]] ==0)
                {
                  int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                  root->arr[i+m1*y[l]][j+m1*x[k]] = -2;
                  root-> arr[i][j] = 0;
                  root->v.push_back(createNode(root->arr , i , j , 'M' ,i+3*y[l] , j+3*x[k] ));
                  root->arr[i+m1*y[l]][j+m1*x[k]]=a; root->arr[i][j]= -2;
                  m1 = 4;
                  if (j+m1*x[k]>=0 && j+m1*x[k]<m && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]>=0)
                  {
                    int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                    root->arr[i+m1*y[l]][j+m1*x[k]] = 0;
                    root->v.push_back(createNode(root->arr , i+2*y[l] , j+2*x[k] , 'B' ,   i+4*y[l] , j+4*x[k]));
                    root->arr[i+m1*y[l]][j+m1*x[k]]=a;
                  }
                  else if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]==0)
                  {
                    m1= 5;
                    if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]>=0)
                    {
                      int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                      root->arr[i+m1*y[l]][j+m1*x[k]] = 0;
                      root->v.push_back(createNode(root->arr, i+2*y[l] , j+2*x[k] , 'B' ,   i+5*y[l] , j+5*x[k]));
                      root->arr[i+m1*y[l]][j+m1*x[k]]=a;
                    }
                  }
                }
                m1= -1;
                if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]] ==0)
                {
                  int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                  root->arr[i+m1*y[l]][j+m1*x[k]] = -2;
                  root-> arr[i+2*y[l]][j+2*x[k] ] = 0;
                  root->v.push_back(createNode(root->arr , i+2*y[l] , j+2*x[k] , 'M' ,i-y[l] , j-x[k] ));
                  root->arr[i+m1*y[l]][j+m1*x[k]]=a; root->arr[i+2*y[l]][j+2*x[k] ]= -2;
                  m1 = -2;
                  if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]>=0)
                  {
                    int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                    root->arr[i+m1*y[l]][j+m1*x[k]] = 0;
                    root->v.push_back(createNode(root->arr , i , j , 'B' ,   i-2*y[l] , j-2*x[k]));
                    root->arr[i+m1*y[l]][j+m1*x[k]]=a;
                  }
                  else if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]==0)
                  {
                    m1= -3;
                    if (j+m1*x[k]>=0 && j+m1*x[k]<m  && i+m1*y[l]>=0 && i+m1*y[l]<n && root->arr[i+m1*y[l]][j+m1*x[k]]>=0)
                    {
                      int a = root->arr[i+m1*y[l]][j+m1*x[k]];
                      root->arr[i+m1*y[l]][j+m1*x[k]] = 0;
                      root->v.push_back(createNode(root->arr, i , j, 'B' ,   i-3*y[l] , j-3*x[k]));
                      root->arr[i+m1*y[l]][j+m1*x[k]]=a;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

void deleteNode(node* n1)
{
  for (int i=0; i<n; i++)
    delete[] n1->arr[i];
  delete[] n1->arr;
  delete n1;
}

void deleteNodeChildren(node* n1)
{
  for (int i=0; i<n1->v.size(); i++)
      deleteNode(n1->v[i]);
}

void deleteNodeChildren(node* n1, node* save)
{
  for (int i=0; i<n1->v.size(); i++)
  {
    if (n1->v[i]!=save)
      deleteNode(n1->v[i]);
  }
}

tuple<node*, int> DFS(node* n, int depth, int alpha, int beta)
{
  n->hValue= utility(n->arr,depth);
  if (depth==MAX_DEPTH)
  {
    deleteNodeChildren(n);
    return make_tuple((node*)NULL, n->hValue);
  }

  if ((depth+player_id)%2==0)
    getValidWhiteMoves(n);
  else
    getValidBlackMoves(n);

  node* retN;
  int retV, retV2;
  if (n->v.empty())
    return make_tuple((node*)NULL, n->hValue);
  
  if ((depth%2)==0)
  {
    // return max of node values of all child
    retN= n->v[0];
    retV= get<1>(DFS(n->v[0], depth+1, alpha, beta));
    alpha=retV;
    for (int i=1; i<n->v.size(); i++)
    {
      if (alpha>=beta)
        break;
      retV2= get<1>(DFS(n->v[i], depth+1, alpha, beta));
      if (retV2>retV)
      {
        retN= n->v[i];
        retV= retV2;
        alpha=retV;
      }
    }

    if (depth==0)
    {
      deleteNodeChildren(n, retN);
    }
    else
    {
      deleteNodeChildren(n);
    }

    return make_tuple(retN, retV);
  }
  else
  {
    retN= n->v[0];
    retV= get<1>(DFS(n->v[0], depth+1, alpha, beta));
    beta=retV;
    for (int i=1; i<n->v.size(); i++)
    {
      if (alpha>=beta)
        break;
      retV2= get<1>(DFS(n->v[i], depth+1, alpha, beta));
      if (retV2<retV)
      {
        retN= n->v[i];
        retV= retV2;
        beta=retV;
      }
    }

    if (depth==0)
    {
      deleteNodeChildren(n, retN);
    }
    else
    {
      deleteNodeChildren(n);
    }

    return make_tuple(retN, retV);
  }
}

string getMove()
{
  string ret;

  node* root= createNode(board);
  node* n= get<0>(DFS(root,0, INT_MIN, INT_MAX));

  ret= "S " + to_string(n->y1) + " " + to_string(n->x1) + " " + n->m + " " + to_string(n->y2) + " " + to_string(n->x2);
  return ret;
}

void sendMove(string move)
{
  cout << move << endl << flush;
}

string getOppMove()
{
  string ret;
  getline(cin, ret);
  return ret;
}

void playMove(string move)
{
  if (move[6]=='M')
  {
    board[move[10]-48][move[8]-48] = board[move[4]-48][move[2]-48];
    board[move[4]-48][move[2]-48] = 0;
  }
  else if (move[6]=='B')
  {
    board[move[10]-48][move[8]-48] = 0;
  }
}


int main()
{
  int movcnt = 0;
  cerr << n <<" "<< m << endl;

  string data;
  getline(cin, data);
  parseData(data);
  initializeBoard();

  string move;

  if (player_id==2)
  {
    move= getOppMove();
    playMove(move);
  }

  while (true)
  {
    move= getMove();
    playMove(move);
    sendMove(move);
    movcnt++;
    if (n == 10 && movcnt == 4 ) MAX_DEPTH= 3;
    if (n == 8 && movcnt == 3) MAX_DEPTH= 4 ;
    move= getOppMove();
    playMove(move);
  }
  cerr << n << m ; 
}