#ifndef HEURISTIC_INCLUDE
#define HEURISTIC_INCLUDE

#include <vector>
using namespace std;
extern double heuristic(vector<vector<int>> &,vector<double> &,int);
#endif

