#!/bin/bash
./main
