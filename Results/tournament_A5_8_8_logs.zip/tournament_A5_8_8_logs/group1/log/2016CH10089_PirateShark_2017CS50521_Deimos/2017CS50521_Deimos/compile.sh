#!/bin/bash
g++ mainBot.cpp Game.cpp EvaluateGame.cpp -o main